
for (let index = 1; index <= 20; index++){
    if (index % 2 == 0) {
        console.log(index);
    } 
}

/* Método alternativo utilizando continue: 

for (let index = 1; index <= 20; index++){
    if (index % 2 != 0) {
        continue;
    } 
    console.log(index);
}

*/
