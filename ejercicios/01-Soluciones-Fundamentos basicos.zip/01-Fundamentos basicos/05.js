let numero = 8;
let indice = 0;

while (indice < numero) {
    alert(`Iterando en el bucle. INDICE = ${indice}`);
    indice++;
}