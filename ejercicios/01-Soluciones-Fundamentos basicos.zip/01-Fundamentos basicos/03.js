let nombre = "Jon";
let apellidos = "Vadillo Romero";
let edad = 99;

let frase = `Me llamo ${nombre} ${apellidos} y tengo ${edad} años`;

// Alternativa
// let frase = "Me llamo " + nombre + " " + apellidos + " y tengo " + edad + " años";

alert(frase);
